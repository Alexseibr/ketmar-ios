# KETMAR Market

Backend и Telegram-бот для маркетплейса объявлений (Node.js 18+, Express, MongoDB/Mongoose, Telegraf).

## ✅ Статус

Приложение **успешно запущено и работает**!

- **API Сервер**: https://workspace.alexseibr.repl.co
- **База данных**: MongoDB Atlas подключена ✅
- **Telegram Бот**: Запущен и готов к работе ✅

## 🚀 Быстрый старт

### Запуск в Replit

1. В разделе **Secrets** добавьте значения:
   - `MONGO_URL` или `MONGODB_URI` — строка подключения к MongoDB
   - `BOT_TOKEN` или `TELEGRAM_BOT_TOKEN` — токен Telegram-бота
   - (опционально) `PORT` — порт API (по умолчанию 5000)
   - (опционально) `API_BASE_URL` — базовый URL API

2. Нажмите **Run** — Replit автоматически выполнит установку зависимостей и запуск

3. Заполните базу данных категориями и сезоном:
   ```bash
   npm run seed
   ```

### Локальный запуск

1. Скопируйте `.env.example` в `.env` и укажите значения
2. Установите зависимости:
   ```bash
   npm install
   ```
3. Запустите сервер и бота:
   ```bash
   npm start
   ```
4. Заполните базу данных:
   ```bash
   npm run seed
   ```

## 📁 Структура проекта

```
workspace/
  index.js                # точка входа: запускает API и бота
  package.json
  
  /config
    config.js             # чтение env, базовые константы
  
  /services
    db.js                 # подключение к MongoDB (mongoose)
  
  /models
    User.js              # Модель пользователя
    Category.js          # Модель категории (иерархическая)
    Season.js            # Модель сезона/ярмарки
    Ad.js                # Модель объявления
    Order.js             # Модель заказа
  
  /api
    server.js            # создание Express-приложения
    /routes
      ads.js             # маршруты объявлений
      categories.js      # маршруты категорий
      seasons.js         # маршруты сезонов
      orders.js          # маршруты заказов
  
  /bot
    bot.js               # Telegraf-бот
  
  /scripts
    seedCategories.js    # заполнение Category и Season стартовыми данными
```

## 🔧 API Endpoints

### Базовые
- `GET /` — информация об API
- `GET /health` — healthcheck

### Категории
- `GET /api/categories` — дерево категорий (parentSlug → subcategories), отсортировано по `sortOrder`

### Сезоны
- `GET /api/seasons` — список всех сезонов
- `GET /api/seasons/active` — только активные сезоны

### Объявления
- `GET /api/ads` — список активных объявлений
  - Query параметры: `limit`, `categoryId`, `subcategoryId`, `seasonCode`
  - Ответ: `{ items: Ad[] }`
- `GET /api/ads/:id` — полное объявление по `_id`
- `POST /api/ads` — создать объявление
  - Обязательные поля: `title`, `categoryId`, `subcategoryId`, `price`, `sellerTelegramId`

### Заказы
- `POST /api/orders` — создать заказ
- `GET /api/orders/:buyerTelegramId` — список заказов покупателя

## 📊 Модели (Mongoose)

### User
Telegram-данные, роль, верификация телефона, соцсети, флаги приватности, локация.

### Category
- `slug` — уникальный идентификатор
- `name` — название
- `parentSlug` — родительская категория (null для корневых)
- `sortOrder` — порядок сортировки

### Season
- `code` — уникальный код (например, "march8_tulips")
- `name` — название
- `description` — описание
- `startDate`, `endDate` — даты начала и окончания
- `isActive` — активность

### Ad
- Категории и подкатегории
- Цена + `currency` (BYN по умолчанию)
- Гибкие `attributes` (Map)
- `photos` (массив URL)
- Опции доставки
- `sellerTelegramId`
- `seasonCode`
- Статусы: draft, active, sold, archived
- `lifetimeDays` и авто-расчёт `validUntil`
- `isLiveSpot` — метка для "живых точек продаж"

### Order
- Покупатель (Telegram ID/имя/username/phone)
- Массив `items` (adId, title, quantity, price, sellerTelegramId)
- `status`: pending, confirmed, processing, completed, cancelled
- `seasonCode`
- `comment`

## 🤖 Telegram-бот

### Команды

- `/start` — приветствие и список команд
- `/myid` — ваш Telegram ID, username и имя
- `/categories` — дерево категорий из API
- `/new_test_ad` — создаёт тестовое объявление с вашим `sellerTelegramId`
- `/cancel` — прерывает мастер создания объявления или оформление заказа

Инлайн-кнопка «Подробнее» в каталоге теперь показывает карточку объявления с характеристиками и ссылкой на оформление. Кнопка «Заказать» запускает мини-мастер: бот попросит указать количество и комментарий и автоматически создаст запись в `/api/orders`, после чего заказ можно отследить через `/myorders`.

## 🌱 Seed-данные

Скрипт `npm run seed` очищает `Category` и `Season`, затем добавляет:

### Категории
- **Авто** (auto) → cars, moto, trucks
- **Недвижимость** (realty) → rent_flat, rent_house, country_base
- **Фермерские товары** (farm) → berries, vegetables, fruits, eggs, milk, meat
- **Ремесленники** (craft) → cakes, eclairs, cupcakes, sweets_sets
- **Услуги** (services) → build, delivery_services

### Сезон
- **code**: `march8_tulips`
- **name**: "Ярмарка 8 Марта — тюльпаны и подарки"
- **Даты**: 01.03.2025 - 10.03.2025
- **Активен**: да

## 🧪 Тестирование

### Проверка API
```bash
# Health check
curl http://localhost:5000/health

# Категории
curl http://localhost:5000/api/categories

# Сезоны
curl http://localhost:5000/api/seasons

# Объявления
curl http://localhost:5000/api/ads
```

### Telegram Бот
1. Найдите вашего бота в Telegram
2. Отправьте `/start`
3. Попробуйте `/categories` — увидите дерево категорий
4. Попробуйте `/new_test_ad` — создастся тестовое объявление
5. Проверьте `/myid` — узнаете свой Telegram ID

## 🛠️ Технологии

- **Runtime**: Node.js 20
- **Backend**: Express.js
- **Database**: MongoDB Atlas, Mongoose
- **Bot Framework**: Telegraf
- **Environment**: Replit

## 📝 Разработка

### Структура конфигурации
Файл `config/config.js` поддерживает оба варианта переменных окружения:
- `MONGO_URL` или `MONGODB_URI`
- `BOT_TOKEN` или `TELEGRAM_BOT_TOKEN`

### Скрипты package.json
- `npm start` — запуск приложения
- `npm run seed` — заполнение базы данных
- `npm run marketplace` — альтернативная команда запуска

## 🎯 Следующие шаги

1. ✅ Заполните базу данных: `npm run seed`
2. ✅ Протестируйте API endpoints
3. ✅ Откройте бота в Telegram и отправьте `/start`
4. ✅ Создайте тестовое объявление: `/new_test_ad`
5. Добавьте больше объявлений через API
6. Реализуйте корзину и оформление заказов
7. Добавьте поиск по объявлениям
8. Внедрите систему уведомлений

---

**Проект готов к использованию!** 🎉

Текущий URL: https://workspace.alexseibr.repl.co
