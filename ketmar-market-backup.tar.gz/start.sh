#!/bin/bash
echo "🚀 Запуск Telegram Marketplace..."
export PORT=5000
exec node index.js
