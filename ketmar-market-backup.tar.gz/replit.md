# KETMAR Market

## Overview

KETMAR Market is a Telegram-based marketplace application for buying and selling goods, with support for seasonal promotions and hierarchical product categories. The system combines a REST API backend built with Express.js and MongoDB, alongside a Telegram bot interface powered by Telegraf for user interactions. The application includes a web admin panel built with React, Vite, and shadcn/ui components for marketplace management.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (Nov 19, 2025)

### Latest Update - Telegram Mini App Integration ✨
- ✅ Добавлен Telegram Mini App SDK (@twa-dev/sdk)
- ✅ Создан Marketplace UI для покупателей в Telegram
- ✅ Автоматическое определение: Admin панель (браузер) vs Marketplace (Telegram)
- ✅ Интеграция корзины и оформления заказов через Mini App
- ✅ Полностью функциональный API сервер (MongoDB + Express + Telegram bot)
- ✅ Все 14 API endpoints протестированы и работают корректно

### Telegram Mini App Files
- **client/src/lib/telegram.ts**: Telegram WebApp SDK wrapper и utility функции
- **client/src/contexts/TelegramProvider.tsx**: React context для Telegram user data
- **client/src/pages/marketplace.tsx**: Marketplace UI для покупателей (каталог товаров + корзина)
- **client/src/App.tsx**: Умная маршрутизация (Telegram → Marketplace, Browser → Admin)

### Web Admin Pages (для операторов)
- **client/src/pages/home.tsx**: Homepage with category filtering and seasonal ads
- **client/src/pages/dashboard-view.tsx**: Analytics dashboard with statistics
- **client/src/pages/categories-view.tsx**: Hierarchical category tree management
- **client/src/pages/ads.tsx**: Ad listings table view
- **client/src/pages/orders.tsx**: Order management interface
- **client/src/components/app-sidebar.tsx**: Navigation menu for all pages

## System Architecture

### Backend Architecture

**Framework**: Node.js with Express.js + TypeScript (mixed CommonJS/ESM modules)

The backend follows a modular architecture with clear separation of concerns:

- **Entry Point** (`index.js`): Launches tsx to run server/backend.ts
- **Unified Server** (`server/backend.ts`): Integrates MongoDB connection, API routes, Telegram bot, and fallback HTML (static files from dist/public if built)
- **Alternative Entry** (`server/index.ts`): Exists but cannot be used due to vite.config.ts top-level await blocking Vite dev server initialization
- **API Layer** (`api/routes/`): RESTful API endpoints for categories, seasons, ads (products), and orders
- **Bot Layer** (`bot/bot.js`): Telegram bot handlers for user commands and inline keyboard interactions
- **Service Layer** (`services/db.js`): MongoDB connection management with Mongoose
- **Configuration** (`config/config.js`): Centralized environment variable handling with fallback support for multiple variable naming conventions

**Design Pattern**: The API uses a route-based modular pattern where each resource (ads, categories, seasons, orders) has its own route file. Error handling is implemented through Express middleware with a centralized error handler.

### Data Architecture

**Database**: MongoDB Atlas (NoSQL document database)

**ODM**: Mongoose for schema validation and data modeling

The data model supports a marketplace with the following entities:

1. **User**: Stores Telegram user information (telegramId, username, firstName, lastName, phone, role, privacy settings)
2. **Category**: Hierarchical category system using `parentSlug` for tree structure, with `sortOrder` for display ordering
3. **Season**: Time-bounded promotional periods with start/end dates and active status
4. **Ad** (Product Listing): User-generated listings with title, description, price, photos, category/subcategory references, and optional season association
5. **Order**: Shopping cart system with multiple order items, buyer information, status tracking, and total price calculation

**Key Architectural Decision**: Categories use a slug-based parent-child relationship rather than ObjectId references, making URLs more readable and API responses more intuitive. The `buildTree()` helper function in the categories route reconstructs the hierarchical structure from flat data.

### Telegram Bot Interface

**Framework**: Telegraf (Telegram Bot API wrapper)

The bot provides these core interactions:

- `/start`: Welcome message and command list
- `/myid`: Display user's Telegram ID and profile information  
- `/categories`: Hierarchical category browser with inline keyboards
- `/catalog`: Browse active ads with product cards
- `/season`: View seasonal promotions
- `/sell`: Create new advertisement (5-step wizard)
- `/my_ads`: View seller's own advertisements
- `/myorders`: View buyer's order history ✨ NEW
- `/new_test_ad`: Create sample advertisements for testing
- Inline keyboards for navigation ("Back", "Home", "Next" buttons)
- **Order Flow** ✨ NEW: Interactive order creation via "🛒 Заказать" button → quantity input → comment → confirmation

**Design Rationale**: The bot acts as the primary user interface for mobile users, while the web admin panel serves marketplace operators. This dual-interface approach optimizes for the mobile-first nature of Telegram while providing robust management tools.

### Frontend Architecture (Dual-Interface System)

**Framework**: React 18 with TypeScript and Vite

**UI Library**: shadcn/ui components built on Radix UI primitives

**State Management**: TanStack Query (React Query) for server state caching and synchronization

**Routing**: Wouter (lightweight client-side routing) with smart environment detection

**Styling**: Tailwind CSS with custom design tokens following Material Design 3 principles

**Telegram Mini App Integration**: 
- SDK: @twa-dev/sdk for Telegram WebApp API
- Context: TelegramProvider for user data and environment detection
- Auto-routing: Detects if running in Telegram vs browser

**Two UI Modes**:

1. **Marketplace UI** (Telegram Mini App - для покупателей):
   - Запускается внутри Telegram через бота
   - Каталог товаров с фильтрацией по категориям
   - Корзина покупок с автоподсчётом суммы
   - Оформление заказов с привязкой к Telegram user ID
   - Адаптивный дизайн для мобильных устройств

2. **Admin Dashboard** (Web Interface - для операторов):
   - **Home**: Landing page with category filtering and seasonal promotions
   - **Dashboard**: Marketplace analytics with statistics cards
   - **Categories**: Hierarchical category tree browser
   - **Ads**: Product listings table with search and filtering
   - **Orders**: Order management with status tracking
   - **Navigation**: Sidebar navigation with icons and page links

**Development Limitation**: Due to top-level await in protected `vite.config.ts` (lines 13, 16 - Replit dev plugins), the frontend cannot be served through `server/index.ts` Vite dev server or built for production. Current workaround: run separate Vite dev server with `cd client && npx vite --port 5173` for frontend development.

**Design Decision**: Dual-interface architecture - Telegram Mini App for customers, Web Admin for marketplace operators. Both share the same backend API endpoints ensuring data consistency.

### API Design

**Style**: RESTful HTTP API with JSON payloads

**Key Endpoints**:

**Categories & Seasons:**
- `GET /api/categories` - Returns hierarchical category tree
- `GET /api/seasons` - List all promotional seasons
- `GET /api/seasons/active` - Get currently active seasons

**Ads (Product Listings):**
- `GET /api/ads` - List advertisements with optional filters (categoryId, subcategoryId, seasonCode, sellerTelegramId)
- `GET /api/ads/:id` - Get single advertisement (increments view counter)
- `POST /api/ads` - Create new advertisement
- `PATCH /api/ads/:id` - Update advertisement

**Orders:** ✨ NEW
- `POST /api/orders` - Create new order with automatic price calculation and validation
- `GET /api/orders/id/:id` - Get single order by ObjectId
- `GET /api/orders/:buyerTelegramId` - Get buyer's order history (sorted by date DESC)
- `PATCH /api/orders/:id` - Update order status (pending → confirmed → processing → completed | cancelled)

**Design Rationale**: The API supports both the Telegram bot and web frontend with the same endpoints. Query parameters enable flexible filtering for different use cases (e.g., filtering ads by season for promotional campaigns). Orders API provides automatic price calculation from current ad data while storing snapshot data to preserve historical accuracy.

### Configuration Management

**Environment Variables**: Supports dual naming conventions for compatibility:
- `MONGO_URL` or `MONGODB_URI` for database connection
- `BOT_TOKEN` or `TELEGRAM_BOT_TOKEN` for Telegram API access
- `PORT` for API server (default: 3000)
- `API_BASE_URL` for bot-to-API communication

**Rationale**: The dual variable support ensures compatibility with different deployment platforms (Replit, Heroku, local development) without requiring code changes.

### Database Design Decisions

**Hierarchical Categories**: The parent-child slug system allows unlimited nesting depth while maintaining simple queries. The `buildTree()` function server-side ensures clients receive structured data without complex queries.

**Season-Based Promotions**: Ads can optionally link to seasonal promotions via `seasonCode`, enabling time-limited marketplace events (e.g., "March 8 Tulips Sale") without disrupting the core product catalog.

**Order Item Denormalization**: Order items store snapshot data (title, price, quantity) at order creation time, preventing historical order data from changing if the source ad is modified or deleted.

**Embedded vs Referenced**: Photos are stored as URL arrays directly in Ad documents rather than separate Photo documents, reducing query complexity for the common case of displaying ads with images.

## External Dependencies

### Database Services

- **MongoDB Atlas**: Cloud-hosted MongoDB database (connection via Mongoose ODM)
- Connection handled through `services/db.js` with automatic reconnection logic

### Third-Party APIs

- **Telegram Bot API**: All bot interactions go through Telegram's servers
- Managed via Telegraf framework (`bot/bot.js`)
- Requires `BOT_TOKEN` for authentication

### Cloud Services

- **Replit**: Deployment platform (optional, supports local development)
- Environment variables configured through Replit Secrets or `.env` file

### NPM Packages (Key Dependencies)

**Backend**:
- `express`: Web server framework
- `mongoose`: MongoDB ODM
- `telegraf`: Telegram Bot API wrapper  
- `dotenv`: Environment variable management

**Frontend**:
- `react` + `react-dom`: UI framework
- `@tanstack/react-query`: Server state management
- `@radix-ui/*`: Unstyled accessible UI primitives
- `tailwindcss`: Utility-first CSS framework
- `wouter`: Lightweight routing
- `zod`: Schema validation
- `react-hook-form`: Form state management

**Development**:
- `vite`: Frontend build tool and dev server
- `typescript`: Type checking
- `drizzle-orm` + `drizzle-kit`: SQL ORM (configured but not actively used; MongoDB is primary database)

### File Upload (Configured)

- `@uppy/core` + `@uppy/aws-s3`: File upload components for product images
- Requires S3-compatible storage configuration (implementation pending)

**Note**: The application includes PostgreSQL/Drizzle configuration files (`drizzle.config.ts`, `shared/schema.ts`) suggesting a potential future migration or parallel SQL database option, but MongoDB is the active production database.