#!/bin/bash

# KETMAR Market - Frontend Development Server
# 
# This script starts the Vite dev server for the React admin panel
# on port 5173 (separate from the main API server on port 5000)
#
# Usage: ./scripts/dev-frontend.sh
# Or: bash scripts/dev-frontend.sh

echo "🎨 Starting KETMAR Market Frontend Development Server..."
echo ""
echo "📍 Frontend will be available at: https://$(echo $REPL_SLUG).$(echo $REPL_OWNER).repl.co:5173"
echo "📍 API server (port 5000): https://$(echo $REPL_SLUG).$(echo $REPL_OWNER).repl.co"
echo ""
echo "Note: Due to vite.config.ts limitations, the frontend must run separately."
echo "      The backend API server should already be running via 'npm run dev'"
echo ""

cd client && npx vite --port 5173 --host 0.0.0.0
