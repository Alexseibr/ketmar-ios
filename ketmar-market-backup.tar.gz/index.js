#!/usr/bin/env node
const { spawn } = require('child_process');
const path = require('path');

console.log('🚀 Запуск KETMAR Market...\n');

process.env.NODE_ENV = process.env.NODE_ENV || 'development';
process.env.PORT = process.env.PORT || '3000';

const tsxPath = path.join(__dirname, 'node_modules', '.bin', 'tsx');
const serverPath = path.join(__dirname, 'server', 'backend.ts');

const tsx = spawn(tsxPath, [serverPath], {
  stdio: 'inherit',
  env: process.env,
  cwd: __dirname
});

tsx.on('close', (code) => {
  process.exit(code || 0);
});

tsx.on('error', (err) => {
  console.error('❌ Ошибка запуска сервера:', err);
  process.exit(1);
});

process.on('SIGINT', () => {
  tsx.kill('SIGINT');
});

process.on('SIGTERM', () => {
  tsx.kill('SIGTERM');
});
