import express from "express";
import { createServer } from "http";

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

(async () => {
  // @ts-ignore - CommonJS modules
  const config = await import('../config/config.js');
  // @ts-ignore - CommonJS modules
  const connectDB = await import('../services/db.js');
  // @ts-ignore - CommonJS modules
  const adsRoutes = await import('../api/routes/ads.js');
  // @ts-ignore - CommonJS modules
  const categoriesRoutes = await import('../api/routes/categories.js');
  // @ts-ignore - CommonJS modules
  const seasonsRoutes = await import('../api/routes/seasons.js');
  // @ts-ignore - CommonJS modules
  const ordersRoutes = await import('../api/routes/orders.js');
  // @ts-ignore - CommonJS modules
  const bot = await import('../bot/bot.js');

  const PORT = config.default.port || 5000;

  try {
    console.log('🚀 Запуск KETMAR Market...\n');
    
    console.log('📊 Подключение к MongoDB...');
    await connectDB.default();
    
    app.use('/api/ads', adsRoutes.default);
    app.use('/api/categories', categoriesRoutes.default);
    app.use('/api/seasons', seasonsRoutes.default);
    app.use('/api/orders', ordersRoutes.default);

    app.get('/health', (_req, res) => {
      res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
      });
    });

    app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
      console.error('❌ Ошибка API:', err);
      res.status(err.status || 500).json({
        message: err.message || 'Внутренняя ошибка сервера',
        ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
      });
    });

    const server = createServer(app);

    if (app.get("env") === "development") {
      const { setupVite } = await import("./vite.js");
      await setupVite(app, server);
    } else {
      const { serveStatic } = await import("./vite.js");
      serveStatic(app);
    }

    console.log('\n🤖 Запуск Telegram бота...');
    try {
      await bot.default.launch();
      console.log('✅ Telegram бот запущен и готов к работе!');
    } catch (botError: any) {
      console.error('⚠️  Ошибка запуска Telegram бота:', botError.message);
      console.log('📡 API сервер продолжит работу без бота');
      if (botError.message.includes('409')) {
        console.log('💡 Возможно, уже запущен другой экземпляр бота. Остановите его перед повторным запуском.');
      }
    }

    server.listen({
      port: PORT,
      host: "0.0.0.0",
      reusePort: true,
    }, () => {
      console.log(`🌐 Сервер запущен на порту ${PORT}`);
      console.log(`   Доступен по адресу: https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`);
    });

    const shutdown = async (signal: string) => {
      console.log(`\n⚠️  Получен сигнал ${signal}. Завершение работы...`);
      
      bot.default.stop(signal);
      console.log('✅ Telegram бот остановлен');
      
      server.close(() => {
        console.log('✅ Сервер остановлен');
        process.exit(0);
      });
    };
    
    process.once('SIGINT', () => shutdown('SIGINT'));
    process.once('SIGTERM', () => shutdown('SIGTERM'));

  } catch (error) {
    console.error('❌ Критическая ошибка при запуске:', error);
    process.exit(1);
  }
})();

process.on('unhandledRejection', (err) => {
  console.error('❌ Unhandled Promise Rejection:', err);
});

process.on('uncaughtException', (err) => {
  console.error('❌ Uncaught Exception:', err);
  process.exit(1);
});
