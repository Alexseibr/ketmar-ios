import express from "express";
import { createServer } from "http";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const log = (message: string) => {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });
  console.log(`${formattedTime} [server] ${message}`);
};

(async () => {
  try {
    console.log('🚀 Запуск KETMAR Market...\n');
    console.log('📊 Подключение к MongoDB...');
    
    // Import and initialize MongoDB
    // @ts-ignore
    const connectDB = await import('../services/db.js');
    await connectDB.default();
    
    // Import API routes
    // @ts-ignore
    const adsRoutes = await import('../api/routes/ads.js');
    // @ts-ignore
    const categoriesRoutes = await import('../api/routes/categories.js');
    // @ts-ignore
    const seasonsRoutes = await import('../api/routes/seasons.js');
    // @ts-ignore
    const ordersRoutes = await import('../api/routes/orders.js');
    
    // Register API routes
    app.use('/api/ads', adsRoutes.default);
    app.use('/api/categories', categoriesRoutes.default);
    app.use('/api/seasons', seasonsRoutes.default);
    app.use('/api/orders', ordersRoutes.default);
    
    // Health check
    app.get('/health', (_req, res) => {
      res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
      });
    });
    
    // Error handler
    app.use((err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
      console.error('❌ Ошибка:', err);
      res.status(err.status || 500).json({
        message: err.message || 'Внутренняя ошибка сервера',
      });
    });
    
    const server = createServer(app);
    const PORT = parseInt(process.env.PORT || '3000', 10);
    
    // Setup Vite dev server (without importing vite.config.ts due to top-level await)
    if (process.env.NODE_ENV !== 'production') {
      const { createServer: createViteServer } = await import('vite');
      const vite = await createViteServer({
        configFile: false,  // Don't load vite.config.ts (has top-level await)
        server: {
          middlewareMode: true,
          hmr: { server },
        },
        appType: 'custom',
        root: path.resolve(__dirname, '../client'),  // Point to client folder
        resolve: {
          alias: {
            '@': path.resolve(__dirname, '../client/src'),
            '@assets': path.resolve(__dirname, '../attached_assets'),
            '@shared': path.resolve(__dirname, '../shared'),
          },
        },
      });

      app.use(vite.middlewares);
      app.use('*', async (req, res, next) => {
        const url = req.originalUrl;
        try {
          // index.html is now in the client/ folder (vite root)
          const template = await fs.promises.readFile(
            path.resolve(__dirname, '../client/index.html'),
            'utf-8'
          );
          const html = await vite.transformIndexHtml(url, template);
          res.status(200).set({ 'Content-Type': 'text/html' }).end(html);
        } catch (e) {
          vite.ssrFixStacktrace(e as Error);
          next(e);
        }
      });

      log('✅ Vite dev server настроен');
    } else {
      // Production mode - serve static files
      const distPath = path.resolve(__dirname, '../dist/public');
      if (fs.existsSync(distPath)) {
        app.use(express.static(distPath));
        app.use('*', (_req, res) => {
          res.sendFile(path.resolve(distPath, 'index.html'));
        });
      }
    }
    
    server.listen({
      port: PORT,
      host: "0.0.0.0",
      reusePort: true,
    }, async () => {
      log(`🌐 Сервер запущен на порту ${PORT}`);
      log(`   Доступен по адресу: https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`);
      
      // Start Telegram bot after server is listening
      console.log('\n🤖 Запуск Telegram бота...');
      try {
        // @ts-ignore
        const bot = await import('../bot/bot.js');
        await bot.default.launch();
        console.log('✅ Telegram бот запущен');
      } catch (botError: any) {
        console.error('⚠️  Ошибка бота:', botError.message);
        console.log('📡 API сервер продолжит работу без бота');
      }
    });
    
    const shutdown = async (signal: string) => {
      console.log(`\n⚠️  Получен сигнал ${signal}`);
      try {
        // @ts-ignore
        const bot = await import('../bot/bot.js');
        bot.default.stop(signal);
      } catch (e) {
        // Bot may not be running
      }
      server.close(() => {
        console.log('✅ Сервер остановлен');
        process.exit(0);
      });
    };
    
    process.once('SIGINT', () => shutdown('SIGINT'));
    process.once('SIGTERM', () => shutdown('SIGTERM'));
    
  } catch (error) {
    console.error('❌ Критическая ошибка:', error);
    process.exit(1);
  }
})();

process.on('unhandledRejection', (err) => {
  console.error('❌ Unhandled Rejection:', err);
});

process.on('uncaughtException', (err) => {
  console.error('❌ Uncaught Exception:', err);
  process.exit(1);
});
