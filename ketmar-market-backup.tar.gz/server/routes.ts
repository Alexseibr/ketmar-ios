import type { Express } from "express";
import { createServer, type Server } from "http";

export async function registerRoutes(app: Express): Promise<Server> {
  // Import and initialize MongoDB connection
  // @ts-ignore - CommonJS module
  const connectDB = await import('../services/db.js');
  await connectDB.default();
  
  // Import existing API routes
  // @ts-ignore - CommonJS module  
  const adsRoutes = await import('../api/routes/ads.js');
  // @ts-ignore - CommonJS module
  const categoriesRoutes = await import('../api/routes/categories.js');
  // @ts-ignore - CommonJS module
  const seasonsRoutes = await import('../api/routes/seasons.js');
  // @ts-ignore - CommonJS module
  const ordersRoutes = await import('../api/routes/orders.js');
  
  // Register API routes
  app.use('/api/ads', adsRoutes.default);
  app.use('/api/categories', categoriesRoutes.default);
  app.use('/api/seasons', seasonsRoutes.default);
  app.use('/api/orders', ordersRoutes.default);
  
  // Health check endpoint
  app.get('/health', (_req, res) => {
    res.json({
      status: 'ok',
      timestamp: new Date().toISOString(),
    });
  });
  
  // Initialize Telegram bot
  try {
    // @ts-ignore - CommonJS module
    const bot = await import('../bot/bot.js');
    await bot.default.launch();
    console.log('✅ Telegram бот запущен и готов к работе!');
  } catch (botError: any) {
    console.error('⚠️  Ошибка запуска Telegram бота:', botError.message);
    console.log('📡 API сервер продолжит работу без бота');
  }

  const httpServer = createServer(app);
  return httpServer;
}
