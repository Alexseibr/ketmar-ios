# 🤖 Telegram Marketplace Bot - Руководство

## ✅ Статус

Приложение **успешно запущено** и работает!

- **API Сервер**: http://localhost:5000
- **База данных**: MongoDB Atlas (подключено ✅)
- **Telegram Бот**: Запущен и готов к работе ✅

## 📊 База данных заполнена

- **5 категорий**: Электроника, Одежда, Дом и сад, Спорт, Книги
- **6 тестовых товаров**: iPhone, Футболка, Кофеварка, и другие

## 🔧 API Endpoints

Все endpoints работают корректно:

```bash
# Health check
curl http://localhost:5000/health

# Получить все категории
curl http://localhost:5000/api/categories

# Получить все товары
curl http://localhost:5000/api/products

# Поиск товаров
curl -X POST http://localhost:5000/api/products/search \
  -H "Content-Type: application/json" \
  -d '{"query": "iPhone"}'

# Получить заказы пользователя
curl http://localhost:5000/api/orders/{telegram_id}
```

## 🤖 Как протестировать Telegram бота

### 1. Найдите своего бота в Telegram

Ваш бот уже создан и работает с токеном из `TELEGRAM_BOT_TOKEN`.

### 2. Откройте бота и нажмите /start

Доступные команды:

- `/start` - Приветствие и список команд
- `/catalog` - Просмотр каталога товаров с фото
- `/categories` - Список всех категорий
- `/search <запрос>` - Поиск товаров (например: `/search телефон`)
- `/myorders` - Просмотр ваших заказов
- `/myid` - Узнать свой Telegram ID
- `/help` - Справка по командам

### 3. Примеры использования

**Просмотр каталога:**
```
/catalog
```
Бот покажет до 5 товаров с фотографиями, описанием и кнопками "В корзину" и "Подробнее".

**Поиск товара:**
```
/search iPhone
```

**Просмотр категорий:**
```
/categories
```

**Мои заказы:**
```
/myorders
```

## 📁 Структура проекта

```
workspace/
├── index.js              # Точка входа (запуск всех сервисов)
├── services/
│   └── db.js            # Подключение к MongoDB
├── api/
│   └── server.js        # Express API сервер
├── bot/
│   └── bot.js           # Telegram бот (Telegraf)
├── models/
│   ├── User.js          # Модель пользователя
│   ├── Category.js      # Модель категории
│   ├── Product.js       # Модель товара
│   └── Order.js         # Модель заказа
└── scripts/
    └── seed.js          # Скрипт заполнения БД тестовыми данными
```

## 🔄 Перезапуск приложения

Приложение уже запущено через Workflow "Start application". Если нужно перезапустить - используйте кнопку перезапуска workflow в Replit.

## 🐛 Отладка

Логи приложения можно посмотреть в консоли Replit или в файлах:
- Workflow "Start application" показывает текущие логи
- MongoDB подключена к Atlas
- Порт 5000 используется для API

## 🎯 Что дальше?

Вы можете:

1. **Добавить больше товаров** через API:
   ```bash
   curl -X POST http://localhost:5000/api/products \
     -H "Content-Type: application/json" \
     -d '{
       "name": "Новый товар",
       "description": "Описание",
       "price": 999,
       "categoryId": "<ID категории>",
       "stock": 10,
       "images": ["https://example.com/image.jpg"]
     }'
   ```

2. **Реализовать корзину** - добавить функциональность сохранения товаров в корзину

3. **Добавить оплату** - интегрировать платежную систему (например, Telegram Payments)

4. **Улучшить UI бота** - добавить inline кнопки, pagination для каталога

5. **Добавить админ-панель** - веб-интерфейс для управления товарами

Удачи! 🚀
