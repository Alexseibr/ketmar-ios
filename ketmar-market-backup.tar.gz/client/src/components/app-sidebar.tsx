import { Home, Package, FolderTree, ShoppingCart, LayoutDashboard } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Link, useLocation } from "wouter";

const menuItems = [
  {
    title: "Главная",
    url: "/",
    icon: Home,
  },
  {
    title: "Панель управления",
    url: "/dashboard",
    icon: LayoutDashboard,
  },
  {
    title: "Все объявления",
    url: "/ads",
    icon: Package,
  },
  {
    title: "Категории",
    url: "/categories",
    icon: FolderTree,
  },
  {
    title: "Заказы",
    url: "/orders",
    icon: ShoppingCart,
  },
];

export function AppSidebar() {
  const [location] = useLocation();

  return (
    <Sidebar>
      <SidebarHeader className="border-b p-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-primary rounded-md flex items-center justify-center text-primary-foreground font-bold">
            K
          </div>
          <div>
            <div className="font-bold text-sm">KETMAR Market</div>
            <div className="text-xs text-muted-foreground">Панель управления</div>
          </div>
        </div>
      </SidebarHeader>
      
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Навигация</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={location === item.url}>
                    <Link href={item.url} data-testid={`nav-${item.url.slice(1) || 'home'}`}>
                      <item.icon />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      
      <SidebarFooter className="border-t p-4">
        <div className="text-xs text-muted-foreground space-y-1">
          <div>Telegram Bot: Активен</div>
          <div>MongoDB: Подключена</div>
          <div>API: Работает</div>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
