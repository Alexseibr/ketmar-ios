import WebApp from '@twa-dev/sdk';

export const tg = WebApp;

export function initTelegramApp() {
  // Initialize Telegram WebApp
  tg.ready();
  
  // Expand to full height
  tg.expand();
  
  // Enable closing confirmation
  tg.enableClosingConfirmation();
  
  // Set header color
  tg.setHeaderColor('bg_color');
  
  console.log('Telegram WebApp initialized:', {
    version: tg.version,
    platform: tg.platform,
    colorScheme: tg.colorScheme,
    user: tg.initDataUnsafe.user,
  });
}

export function getTelegramUser() {
  return tg.initDataUnsafe.user || null;
}

export function isTelegramEnvironment() {
  return tg.initDataUnsafe.user !== undefined;
}

export function showTelegramAlert(message: string) {
  tg.showAlert(message);
}

export function showTelegramConfirm(message: string, callback: (confirmed: boolean) => void) {
  tg.showConfirm(message, callback);
}

export function closeTelegramApp() {
  tg.close();
}

export default tg;
