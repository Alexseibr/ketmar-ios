import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { tg, initTelegramApp, getTelegramUser, isTelegramEnvironment } from '@/lib/telegram';

interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  is_premium?: boolean;
}

interface TelegramContextType {
  user: TelegramUser | null;
  isReady: boolean;
  isTelegram: boolean;
  colorScheme: 'light' | 'dark';
  tg: typeof tg;
}

const TelegramContext = createContext<TelegramContextType | null>(null);

interface TelegramProviderProps {
  children: ReactNode;
}

export function TelegramProvider({ children }: TelegramProviderProps) {
  const [user, setUser] = useState<TelegramUser | null>(null);
  const [isReady, setIsReady] = useState(false);
  const [isTelegram, setIsTelegram] = useState(false);
  const [colorScheme, setColorScheme] = useState<'light' | 'dark'>('light');

  useEffect(() => {
    // Initialize Telegram WebApp
    if (isTelegramEnvironment()) {
      initTelegramApp();
      setIsTelegram(true);
      setUser(getTelegramUser());
      setColorScheme(tg.colorScheme);
      
      // Listen for color scheme changes
      tg.onEvent('themeChanged', () => {
        setColorScheme(tg.colorScheme);
      });
    }
    
    setIsReady(true);
  }, []);

  const value: TelegramContextType = {
    user,
    isReady,
    isTelegram,
    colorScheme,
    tg,
  };

  return (
    <TelegramContext.Provider value={value}>
      {children}
    </TelegramContext.Provider>
  );
}

export function useTelegram() {
  const context = useContext(TelegramContext);
  if (!context) {
    throw new Error('useTelegram must be used within TelegramProvider');
  }
  return context;
}
