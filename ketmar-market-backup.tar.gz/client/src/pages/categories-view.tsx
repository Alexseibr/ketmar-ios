import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { FolderTree, ChevronRight } from "lucide-react";

interface Category {
  slug: string;
  name: string;
  parentSlug: string | null;
  subcategories: Category[];
}

export default function CategoriesView() {
  const { data: categories, isLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const renderCategory = (category: Category, level: number = 0) => {
    return (
      <div key={category.slug} className="space-y-2">
        <Card 
          className="hover-elevate"
          data-testid={`card-category-${category.slug}`}
          style={{ marginLeft: `${level * 1.5}rem` }}
        >
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              {level > 0 && <ChevronRight className="h-4 w-4 text-muted-foreground" />}
              <div className="flex-1">
                <h3 className="font-semibold text-lg" data-testid={`text-name-${category.slug}`}>
                  {category.name}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {category.slug}
                </p>
              </div>
              <div className="flex items-center gap-2">
                {category.subcategories && category.subcategories.length > 0 && (
                  <Badge variant="secondary" data-testid={`badge-count-${category.slug}`}>
                    {category.subcategories.length} подкатегорий
                  </Badge>
                )}
                <Badge 
                  variant={category.parentSlug ? "outline" : "default"}
                  data-testid={`badge-level-${category.slug}`}
                >
                  {category.parentSlug ? "Подкатегория" : "Основная"}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {category.subcategories && category.subcategories.map((sub) => 
          renderCategory(sub, level + 1)
        )}
      </div>
    );
  };

  return (
    <div className="flex flex-col gap-6 p-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="heading-categories">
          Категории
        </h1>
        <p className="text-muted-foreground mt-1">
          Иерархическая структура категорий маркетплейса
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FolderTree className="h-5 w-5" />
            Дерево категорий
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {[...Array(8)].map((_, i) => (
                <Skeleton key={i} className="h-20 w-full" />
              ))}
            </div>
          ) : !categories || categories.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <FolderTree className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">Категорий нет</h3>
              <p className="text-muted-foreground">
                Категории будут добавлены в базу данных
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {categories
                .filter(cat => !cat.parentSlug)
                .map((category) => renderCategory(category))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="bg-muted/30">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              Всего категорий: <span className="font-semibold">{categories?.length || 0}</span>
            </p>
            <p className="text-xs text-muted-foreground">
              Данные из MongoDB
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
