import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Package, Eye, ShoppingCart, Filter } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface Ad {
  _id: string;
  title: string;
  description?: string;
  price: number;
  currency: string;
  categoryId: string;
  subcategoryId: string;
  photos: string[];
  status: string;
  views: number;
  createdAt: string;
}

interface Category {
  slug: string;
  name: string;
  subcategories: Category[];
}

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  
  const adsUrl = selectedCategory !== "all" 
    ? `/api/ads?categoryId=${selectedCategory}`
    : "/api/ads";
    
  const { data: ads, isLoading: adsLoading } = useQuery<{ items: Ad[] }>({
    queryKey: [adsUrl],
  });

  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const getStatusBadge = (status: string) => {
    const statusConfig: Record<string, { variant: "default" | "secondary" | "outline" | "destructive"; label: string }> = {
      active: { variant: "default", label: "Активно" },
      draft: { variant: "secondary", label: "Черновик" },
      sold: { variant: "outline", label: "Продано" },
      archived: { variant: "destructive", label: "Архив" },
    };
    const config = statusConfig[status] || { variant: "secondary", label: status };
    return <Badge variant={config.variant} data-testid={`badge-status-${status}`}>{config.label}</Badge>;
  };

  return (
    <div className="flex flex-col gap-6 p-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-4xl font-bold" data-testid="heading-home">
            KETMAR Market
          </h1>
          <p className="text-muted-foreground mt-2">
            Маркетплейс товаров и услуг через Telegram
          </p>
        </div>
      </div>

      {/* Filter */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Фильтры
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger data-testid="select-category">
                  <SelectValue placeholder="Все категории" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Все категории</SelectItem>
                  {categoriesLoading ? (
                    <SelectItem value="loading" disabled>Загрузка...</SelectItem>
                  ) : (
                    categories?.map((cat) => (
                      <SelectItem key={cat.slug} value={cat.slug}>
                        {cat.name}
                      </SelectItem>
                    ))
                  )}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Ads Grid */}
      {adsLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-3/4" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-40 w-full mb-4" />
                <Skeleton className="h-4 w-full mb-2" />
                <Skeleton className="h-4 w-2/3" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : !ads?.items || ads.items.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16 text-center">
            <Package className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">Объявлений не найдено</h3>
            <p className="text-muted-foreground mb-4">
              Попробуйте изменить фильтры или создать новое объявление через Telegram бота
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              Найдено объявлений: <span className="font-semibold">{ads.items.length}</span>
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {ads.items.map((ad) => (
              <Card 
                key={ad._id} 
                className="hover-elevate overflow-hidden flex flex-col"
                data-testid={`card-ad-${ad._id}`}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-2">
                    <CardTitle className="text-lg line-clamp-2" data-testid={`text-title-${ad._id}`}>
                      {ad.title}
                    </CardTitle>
                    {getStatusBadge(ad.status)}
                  </div>
                </CardHeader>
                
                <CardContent className="flex-1 space-y-3">
                  {ad.photos && ad.photos.length > 0 ? (
                    <div className="aspect-video bg-muted rounded-md overflow-hidden">
                      <img
                        src={ad.photos[0]}
                        alt={ad.title}
                        className="w-full h-full object-cover"
                        data-testid={`img-ad-${ad._id}`}
                      />
                    </div>
                  ) : (
                    <div className="aspect-video bg-muted rounded-md flex items-center justify-center">
                      <Package className="h-12 w-12 text-muted-foreground" />
                    </div>
                  )}
                  
                  {ad.description && (
                    <p className="text-sm text-muted-foreground line-clamp-2" data-testid={`text-description-${ad._id}`}>
                      {ad.description}
                    </p>
                  )}
                  
                  <div className="flex items-center justify-between pt-2">
                    <div>
                      <p className="text-2xl font-bold text-primary" data-testid={`text-price-${ad._id}`}>
                        {ad.price} {ad.currency}
                      </p>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Eye className="h-3 w-3" />
                      <span data-testid={`text-views-${ad._id}`}>{ad.views}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-2 text-xs">
                    <Badge variant="outline" data-testid={`badge-category-${ad._id}`}>
                      {ad.categoryId}
                    </Badge>
                    {ad.subcategoryId && (
                      <Badge variant="outline" data-testid={`badge-subcategory-${ad._id}`}>
                        {ad.subcategoryId}
                      </Badge>
                    )}
                  </div>
                </CardContent>
                
                <CardFooter className="pt-4 gap-2">
                  <Button 
                    variant="outline" 
                    className="flex-1"
                    data-testid={`button-view-${ad._id}`}
                  >
                    <Eye className="h-4 w-4 mr-2" />
                    Подробнее
                  </Button>
                  {ad.status === "active" && (
                    <Button 
                      variant="default" 
                      className="flex-1"
                      data-testid={`button-order-${ad._id}`}
                    >
                      <ShoppingCart className="h-4 w-4 mr-2" />
                      Заказать
                    </Button>
                  )}
                </CardFooter>
              </Card>
            ))}
          </div>
        </>
      )}

      {/* Info Card */}
      <Card className="bg-primary/5">
        <CardContent className="pt-6">
          <p className="text-center text-sm text-muted-foreground">
            Чтобы создать объявление или оформить заказ, используйте Telegram бота @ketmar_bot
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
