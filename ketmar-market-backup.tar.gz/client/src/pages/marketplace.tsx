import { useState, useEffect } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useTelegram } from '@/contexts/TelegramProvider';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { ShoppingCart, Package, Search, Plus, Minus, Trash2 } from 'lucide-react';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface Ad {
  _id: string;
  title: string;
  description?: string;
  price: number;
  currency: string;
  categoryId: string;
  subcategoryId: string;
  photos?: string[];
  sellerTelegramId: number;
  deliveryOptions?: string[];
  seasonCode?: string;
}

interface Category {
  slug: string;
  name: string;
  subcategories: Category[];
}

const CART_STORAGE_KEY = 'ketmar_cart';

export default function Marketplace() {
  const { user, isTelegram, isReady } = useTelegram();
  const { toast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState<{ ad: Ad; quantity: number }[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCartLoaded, setIsCartLoaded] = useState(false);

  // Load cart from localStorage after Telegram environment is ready
  useEffect(() => {
    // Wait for Telegram provider to initialize
    if (!isReady) {
      return;
    }

    // Not in Telegram - skip cart loading
    if (!isTelegram) {
      setIsCartLoaded(true);
      return;
    }

    // Wait for user data from Telegram
    if (!user) {
      return;
    }
    
    try {
      const storageKey = `${CART_STORAGE_KEY}_${user.id}`;
      const stored = localStorage.getItem(storageKey);
      if (stored) {
        const parsed = JSON.parse(stored);
        setCart(parsed);
      }
    } catch (error) {
      console.error('Failed to load cart from localStorage:', error);
    } finally {
      setIsCartLoaded(true);
    }
  }, [isReady, isTelegram, user]);

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    if (!isTelegram || !user) return;
    
    try {
      const storageKey = `${CART_STORAGE_KEY}_${user.id}`;
      localStorage.setItem(storageKey, JSON.stringify(cart));
    } catch (error) {
      console.error('Failed to save cart to localStorage:', error);
    }
  }, [cart, isTelegram, user]);

  // Fetch categories
  const { data: categories = [] } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  // Fetch ads
  const { data: adsData } = useQuery<{ items: Ad[] }>({
    queryKey: ['/api/ads', selectedCategory],
    enabled: true,
  });

  const ads = adsData?.items || [];

  // Filter ads by search
  const filteredAds = ads.filter(ad => 
    ad.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    ad.description?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Create order mutation
  const createOrderMutation = useMutation({
    mutationFn: async (orderData: any) => {
      // Additional validation before sending
      if (!isTelegram || !user || cart.length === 0) {
        throw new Error('Invalid checkout state');
      }
      return await apiRequest('/api/orders', 'POST', orderData);
    },
    onSuccess: () => {
      toast({
        title: '✅ Заказ создан',
        description: 'Ваш заказ успешно оформлен!',
      });
      
      // Clear cart from state and localStorage
      setCart([]);
      if (user) {
        try {
          const storageKey = `${CART_STORAGE_KEY}_${user.id}`;
          localStorage.removeItem(storageKey);
        } catch (error) {
          console.error('Failed to clear cart from localStorage:', error);
        }
      }
      
      queryClient.invalidateQueries({ queryKey: ['/api/orders'] });
    },
    onError: (error: any) => {
      toast({
        title: '❌ Ошибка',
        description: error.message || 'Не удалось создать заказ',
        variant: 'destructive',
      });
    },
  });

  const addToCart = (ad: Ad) => {
    const existing = cart.find(item => item.ad._id === ad._id);
    if (existing) {
      setCart(cart.map(item =>
        item.ad._id === ad._id ? { ...item, quantity: item.quantity + 1 } : item
      ));
    } else {
      setCart([...cart, { ad, quantity: 1 }]);
    }
    toast({
      title: '🛒 Добавлено в корзину',
      description: ad.title,
    });
  };

  const removeFromCart = (adId: string) => {
    setCart(cart.filter(item => item.ad._id !== adId));
  };

  const updateQuantity = (adId: string, quantity: number) => {
    // Validate and clamp quantity
    const validQuantity = Math.max(1, Math.floor(quantity || 1));
    
    if (validQuantity <= 0 || isNaN(validQuantity)) {
      removeFromCart(adId);
    } else {
      setCart(cart.map(item =>
        item.ad._id === adId ? { ...item, quantity: validQuantity } : item
      ));
    }
  };

  const handleCheckout = () => {
    if (!isTelegram || !user) {
      toast({
        title: '❌ Ошибка',
        description: 'Функция доступна только в Telegram',
        variant: 'destructive',
      });
      return;
    }

    if (cart.length === 0) {
      toast({
        title: '❌ Ошибка',
        description: 'Корзина пуста',
        variant: 'destructive',
      });
      return;
    }

    const orderData = {
      buyerTelegramId: user.id,
      items: cart.map(item => ({
        adId: item.ad._id,
        quantity: item.quantity,
        comment: '',
      })),
    };

    createOrderMutation.mutate(orderData);
  };

  const totalPrice = cart.reduce((sum, item) => sum + item.ad.price * item.quantity, 0);
  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  // Show loading state while cart is being hydrated
  if (!isCartLoaded) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <p className="text-muted-foreground">Загрузка marketplace...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container max-w-4xl mx-auto p-4 pb-20">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold mb-2">KETMAR Market</h1>
          <p className="text-sm text-muted-foreground">
            Привет, {user?.first_name}! 👋
          </p>
        </div>

        {/* Search */}
        <div className="mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Поиск товаров..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
              data-testid="input-search"
            />
          </div>
        </div>

        {/* Categories */}
        <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="mb-6">
          <TabsList className="w-full justify-start overflow-x-auto">
            <TabsTrigger value="" data-testid="tab-all">Все</TabsTrigger>
            {categories.map(cat => (
              <TabsTrigger key={cat.slug} value={cat.slug} data-testid={`tab-${cat.slug}`}>
                {cat.name}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {filteredAds.length === 0 ? (
            <Card className="col-span-full">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Package className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">Товары не найдены</p>
              </CardContent>
            </Card>
          ) : (
            filteredAds.map(ad => (
              <Card key={ad._id} data-testid={`card-ad-${ad._id}`}>
                {ad.photos && ad.photos.length > 0 && (
                  <div className="aspect-video w-full overflow-hidden bg-muted">
                    <img 
                      src={ad.photos[0]} 
                      alt={ad.title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
                <CardHeader>
                  <div className="flex items-start justify-between gap-2">
                    <CardTitle className="text-base line-clamp-2">{ad.title}</CardTitle>
                    {ad.seasonCode && (
                      <Badge variant="secondary" className="shrink-0">
                        {ad.seasonCode}
                      </Badge>
                    )}
                  </div>
                  {ad.description && (
                    <CardDescription className="line-clamp-2">
                      {ad.description}
                    </CardDescription>
                  )}
                </CardHeader>
                <CardFooter className="flex items-center justify-between">
                  <div>
                    <p className="text-xl font-bold">{ad.price} {ad.currency}</p>
                    {ad.deliveryOptions && ad.deliveryOptions.length > 0 && (
                      <p className="text-xs text-muted-foreground">
                        {ad.deliveryOptions.join(', ')}
                      </p>
                    )}
                  </div>
                  <Button 
                    size="sm" 
                    onClick={() => addToCart(ad)}
                    disabled={!isTelegram}
                    data-testid={`button-add-to-cart-${ad._id}`}
                  >
                    <ShoppingCart className="h-4 w-4 mr-1" />
                    В корзину
                  </Button>
                </CardFooter>
              </Card>
            ))
          )}
        </div>

        {/* Cart Summary (Fixed Bottom) */}
        {cart.length > 0 && (
          <div className="fixed bottom-0 left-0 right-0 bg-background border-t p-4 shadow-lg">
            <div className="container max-w-4xl mx-auto">
              <div className="flex items-center justify-between gap-4">
                <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
                  <SheetTrigger asChild>
                    <Button variant="outline" size="lg" data-testid="button-open-cart">
                      <ShoppingCart className="h-5 w-5 mr-2" />
                      <span className="font-semibold">{totalItems}</span>
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="bottom" className="h-[80vh] flex flex-col">
                    <SheetHeader>
                      <SheetTitle>Корзина</SheetTitle>
                      <SheetDescription>
                        {totalItems} {totalItems === 1 ? 'товар' : 'товаров'} на сумму {totalPrice} BYN
                      </SheetDescription>
                    </SheetHeader>
                    
                    <div className="flex-1 overflow-y-auto mt-6 space-y-4 pb-32">
                      {cart.map((item) => (
                        <Card key={item.ad._id} data-testid={`cart-item-${item.ad._id}`}>
                          <CardContent className="p-4">
                            <div className="flex items-start justify-between gap-4">
                              <div className="flex-1 min-w-0">
                                <h3 className="font-medium line-clamp-2">{item.ad.title}</h3>
                                <p className="text-sm text-muted-foreground">
                                  {item.ad.price} {item.ad.currency}
                                </p>
                              </div>
                              
                              <div className="flex flex-col items-end gap-2">
                                <div className="flex items-center gap-2">
                                  <Button
                                    size="icon"
                                    variant="outline"
                                    onClick={() => updateQuantity(item.ad._id, item.quantity - 1)}
                                    data-testid={`button-decrease-${item.ad._id}`}
                                  >
                                    <Minus className="h-4 w-4" />
                                  </Button>
                                  
                                  <Input
                                    type="number"
                                    value={item.quantity}
                                    onChange={(e) => {
                                      const val = parseInt(e.target.value);
                                      if (!isNaN(val) && val >= 1) {
                                        updateQuantity(item.ad._id, val);
                                      }
                                    }}
                                    onBlur={(e) => {
                                      const val = parseInt(e.target.value);
                                      if (isNaN(val) || val < 1) {
                                        updateQuantity(item.ad._id, 1);
                                      }
                                    }}
                                    className="w-16 text-center"
                                    min="1"
                                    data-testid={`input-quantity-${item.ad._id}`}
                                  />
                                  
                                  <Button
                                    size="icon"
                                    variant="outline"
                                    onClick={() => updateQuantity(item.ad._id, item.quantity + 1)}
                                    data-testid={`button-increase-${item.ad._id}`}
                                  >
                                    <Plus className="h-4 w-4" />
                                  </Button>
                                </div>
                                
                                <div className="flex items-center gap-2">
                                  <span className="text-sm font-semibold">
                                    {item.ad.price * item.quantity} {item.ad.currency}
                                  </span>
                                  <Button
                                    size="icon"
                                    variant="ghost"
                                    onClick={() => removeFromCart(item.ad._id)}
                                    data-testid={`button-remove-${item.ad._id}`}
                                  >
                                    <Trash2 className="h-4 w-4 text-destructive" />
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>

                    <div className="sticky bottom-0 left-0 right-0 p-6 bg-background border-t mt-auto">
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-lg font-semibold">Итого:</span>
                        <span className="text-2xl font-bold">{totalPrice} BYN</span>
                      </div>
                      <Button
                        size="lg"
                        className="w-full"
                        onClick={() => {
                          handleCheckout();
                          setIsCartOpen(false);
                        }}
                        disabled={createOrderMutation.isPending || cart.length === 0}
                        data-testid="button-checkout-from-cart"
                      >
                        {createOrderMutation.isPending ? 'Оформление...' : 'Оформить заказ'}
                      </Button>
                    </div>
                  </SheetContent>
                </Sheet>

                <div className="flex-1">
                  <p className="text-sm text-muted-foreground">
                    {totalItems} {totalItems === 1 ? 'товар' : 'товаров'}
                  </p>
                  <p className="text-xl font-bold">
                    {totalPrice} BYN
                  </p>
                </div>
                
                <Button 
                  size="lg"
                  onClick={handleCheckout}
                  disabled={createOrderMutation.isPending || cart.length === 0}
                  data-testid="button-checkout"
                >
                  {createOrderMutation.isPending ? 'Оформление...' : 'Оформить заказ'}
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
