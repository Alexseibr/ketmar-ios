import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Package, ShoppingCart, FolderTree, TrendingUp, Eye, Users } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

interface Ad {
  _id: string;
  status: string;
  views: number;
}

interface Category {
  slug: string;
  name: string;
}

export default function DashboardView() {
  const { data: adsData, isLoading: adsLoading } = useQuery<{ items: Ad[] }>({
    queryKey: ["/api/ads"],
  });

  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  // Подсчёт статистики
  const activeAds = adsData?.items.filter(ad => ad.status === "active").length || 0;
  const totalAds = adsData?.items.length || 0;
  const totalViews = adsData?.items.reduce((sum, ad) => sum + (ad.views || 0), 0) || 0;
  const totalCategories = categories?.length || 0;

  const isLoading = adsLoading || categoriesLoading;

  const statCards = [
    {
      title: "Всего объявлений",
      value: totalAds,
      icon: Package,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
      testId: "stat-total-ads",
    },
    {
      title: "Активные объявления",
      value: activeAds,
      icon: TrendingUp,
      color: "text-green-600",
      bgColor: "bg-green-100",
      testId: "stat-active-ads",
    },
    {
      title: "Категорий",
      value: totalCategories,
      icon: FolderTree,
      color: "text-purple-600",
      bgColor: "bg-purple-100",
      testId: "stat-categories",
    },
    {
      title: "Просмотров",
      value: totalViews,
      icon: Eye,
      color: "text-orange-600",
      bgColor: "bg-orange-100",
      testId: "stat-views",
    },
  ];

  return (
    <div className="flex flex-col gap-6 p-6">
      <div>
        <h1 className="text-4xl font-bold" data-testid="heading-dashboard">
          Панель управления
        </h1>
        <p className="text-muted-foreground mt-2">
          Статистика KETMAR Market
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((stat) => (
          <Card key={stat.title} data-testid={stat.testId} className="hover-elevate">
            <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
              <div className={`p-2 rounded-md ${stat.bgColor}`}>
                <stat.icon className={`h-4 w-4 ${stat.color}`} />
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <Skeleton className="h-8 w-20" />
              ) : (
                <div 
                  className="text-3xl font-bold" 
                  data-testid={`value-${stat.testId}`}
                >
                  {stat.value.toLocaleString()}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card data-testid="card-welcome">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Добро пожаловать
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-muted-foreground">
              Это панель управления маркетплейсом KETMAR Market
            </p>
            <div className="space-y-2 text-sm">
              <div className="flex items-start gap-2">
                <div className="w-2 h-2 rounded-full bg-primary mt-1.5" />
                <p>
                  <span className="font-semibold">Telegram бот</span> подключен и готов к работе
                </p>
              </div>
              <div className="flex items-start gap-2">
                <div className="w-2 h-2 rounded-full bg-primary mt-1.5" />
                <p>
                  <span className="font-semibold">MongoDB</span> хранит все данные в реальном времени
                </p>
              </div>
              <div className="flex items-start gap-2">
                <div className="w-2 h-2 rounded-full bg-primary mt-1.5" />
                <p>
                  <span className="font-semibold">REST API</span> обрабатывает запросы
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="card-quick-stats" className="bg-gradient-to-br from-primary/10 to-primary/5">
          <CardHeader>
            <CardTitle>Быстрая статистика</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Процент активных</span>
              <span className="font-bold text-lg">
                {totalAds > 0 ? Math.round((activeAds / totalAds) * 100) : 0}%
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Среднее просмотров</span>
              <span className="font-bold text-lg">
                {totalAds > 0 ? Math.round(totalViews / totalAds) : 0}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Объявлений на категорию</span>
              <span className="font-bold text-lg">
                {totalCategories > 0 ? Math.round(totalAds / totalCategories) : 0}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-muted/30">
        <CardContent className="pt-6">
          <div className="text-center space-y-2">
            <p className="text-sm text-muted-foreground">
              Создавайте объявления и оформляйте заказы через Telegram бота
            </p>
            <p className="text-xs text-muted-foreground">
              Команды: /sell (создать объявление), /catalog (каталог), /myorders (заказы)
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
