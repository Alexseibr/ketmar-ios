import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Package, Eye, Calendar } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface Ad {
  _id: string;
  title: string;
  description?: string;
  price: number;
  currency: string;
  categoryId: string;
  subcategoryId: string;
  sellerTelegramId: number;
  status: string;
  views: number;
  createdAt: string;
}

export default function Ads() {
  const { data: ads, isLoading } = useQuery<{ items: Ad[] }>({
    queryKey: ["/api/ads"],
  });

  const getStatusBadge = (status: string) => {
    const statusConfig: Record<string, { variant: "default" | "secondary" | "outline" | "destructive"; label: string }> = {
      active: { variant: "default", label: "Активно" },
      draft: { variant: "secondary", label: "Черновик" },
      sold: { variant: "outline", label: "Продано" },
      archived: { variant: "destructive", label: "Архив" },
    };
    const config = statusConfig[status] || { variant: "secondary", label: status };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
    });
  };

  return (
    <div className="flex flex-col gap-6 p-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="heading-ads">
          Все объявления
        </h1>
        <p className="text-muted-foreground mt-1">
          Полный список объявлений на маркетплейсе
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Объявления</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {[...Array(8)].map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : !ads?.items || ads.items.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Package className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">Объявлений пока нет</h3>
              <p className="text-muted-foreground">
                Объявления появятся здесь после создания через Telegram бота
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Название</TableHead>
                    <TableHead>Категория</TableHead>
                    <TableHead>Цена</TableHead>
                    <TableHead>Продавец ID</TableHead>
                    <TableHead>Статус</TableHead>
                    <TableHead>Просмотры</TableHead>
                    <TableHead>Создано</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {ads.items.map((ad) => (
                    <TableRow key={ad._id} data-testid={`row-ad-${ad._id}`}>
                      <TableCell className="font-medium max-w-xs" data-testid={`text-title-${ad._id}`}>
                        <div className="line-clamp-1">{ad.title}</div>
                        {ad.description && (
                          <div className="text-xs text-muted-foreground line-clamp-1">
                            {ad.description}
                          </div>
                        )}
                      </TableCell>
                      <TableCell data-testid={`text-category-${ad._id}`}>
                        <div className="flex flex-col gap-1">
                          <Badge variant="outline" className="w-fit">{ad.categoryId}</Badge>
                          {ad.subcategoryId && (
                            <Badge variant="secondary" className="w-fit text-xs">
                              {ad.subcategoryId}
                            </Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell data-testid={`text-price-${ad._id}`}>
                        <span className="font-semibold">{ad.price}</span> {ad.currency}
                      </TableCell>
                      <TableCell data-testid={`text-seller-${ad._id}`}>
                        <code className="text-xs">{ad.sellerTelegramId}</code>
                      </TableCell>
                      <TableCell>{getStatusBadge(ad.status)}</TableCell>
                      <TableCell data-testid={`text-views-${ad._id}`}>
                        <div className="flex items-center gap-1">
                          <Eye className="h-3 w-3 text-muted-foreground" />
                          {ad.views}
                        </div>
                      </TableCell>
                      <TableCell data-testid={`text-date-${ad._id}`}>
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <Calendar className="h-3 w-3" />
                          {formatDate(ad.createdAt)}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="bg-muted/30">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              Всего объявлений: <span className="font-semibold">{ads?.items.length || 0}</span>
            </p>
            <p className="text-xs text-muted-foreground">
              Обновляется в реальном времени из MongoDB
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
