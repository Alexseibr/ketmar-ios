import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ShoppingCart, Calendar, User, Package } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

interface OrderItem {
  adId: string;
  title: string;
  quantity: number;
  price: number;
  currency: string;
  sellerTelegramId: number;
}

interface Order {
  _id: string;
  buyerTelegramId: number;
  buyerName?: string;
  buyerUsername?: string;
  items: OrderItem[];
  totalPrice: number;
  status: string;
  comment?: string;
  createdAt: string;
  updatedAt: string;
}

export default function Orders() {
  // В реальности можно было бы фильтровать по buyerTelegramId
  // Для демонстрации используем общий endpoint (который не существует в API)
  // Можно добавить endpoint GET /api/orders/all для админа
  const { data: orders, isLoading } = useQuery<Order[]>({
    queryKey: ["/api/orders/all"],
    // Этот endpoint нужно будет добавить на бэкенде
    retry: false,
  });

  const getStatusBadge = (status: string) => {
    const statusConfig: Record<string, { variant: "default" | "secondary" | "outline" | "destructive"; label: string }> = {
      pending: { variant: "secondary", label: "Ожидает" },
      confirmed: { variant: "default", label: "Подтверждён" },
      processing: { variant: "outline", label: "В обработке" },
      completed: { variant: "default", label: "Завершён" },
      cancelled: { variant: "destructive", label: "Отменён" },
    };
    const config = statusConfig[status] || { variant: "secondary", label: status };
    return <Badge variant={config.variant}>{config.label}</Badge>;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString("ru-RU", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  return (
    <div className="flex flex-col gap-6 p-6">
      <div>
        <h1 className="text-3xl font-bold" data-testid="heading-orders">
          Заказы
        </h1>
        <p className="text-muted-foreground mt-1">
          Все заказы с маркетплейса
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShoppingCart className="h-5 w-5" />
            История заказов
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              {[...Array(6)].map((_, i) => (
                <Skeleton key={i} className="h-24 w-full" />
              ))}
            </div>
          ) : !orders || orders.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <ShoppingCart className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">Заказов пока нет</h3>
              <p className="text-muted-foreground mb-4">
                Заказы появятся здесь после оформления через Telegram бота
              </p>
              <p className="text-xs text-muted-foreground">
                Используйте команду /catalog и кнопку "Заказать" в боте
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {orders.map((order) => (
                <Card 
                  key={order._id} 
                  className="hover-elevate"
                  data-testid={`card-order-${order._id}`}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <CardTitle className="text-lg">
                            Заказ #{order._id.slice(-6)}
                          </CardTitle>
                          {getStatusBadge(order.status)}
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <User className="h-3 w-3" />
                            {order.buyerName || `ID: ${order.buyerTelegramId}`}
                          </div>
                          {order.buyerUsername && (
                            <div>@{order.buyerUsername}</div>
                          )}
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {formatDate(order.createdAt)}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-primary">
                          {order.totalPrice} BYN
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {order.items.length} товаров
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="text-sm font-medium">Товары:</div>
                      {order.items.map((item, idx) => (
                        <div 
                          key={idx}
                          className="flex items-center justify-between p-3 bg-muted/50 rounded-md"
                        >
                          <div className="flex items-center gap-2">
                            <Package className="h-4 w-4 text-muted-foreground" />
                            <div>
                              <div className="font-medium">{item.title}</div>
                              <div className="text-xs text-muted-foreground">
                                Количество: {item.quantity}
                              </div>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-semibold">
                              {item.price * item.quantity} {item.currency}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {item.price} × {item.quantity}
                            </div>
                          </div>
                        </div>
                      ))}
                      
                      {order.comment && (
                        <div className="mt-3 p-3 bg-primary/5 rounded-md">
                          <div className="text-xs font-medium text-muted-foreground mb-1">
                            Комментарий:
                          </div>
                          <div className="text-sm">{order.comment}</div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {orders && orders.length > 0 && (
        <Card className="bg-muted/30">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                Всего заказов: <span className="font-semibold">{orders.length}</span>
              </p>
              <p className="text-xs text-muted-foreground">
                Обновляется в реальном времени из MongoDB
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
